extern unsigned long int strtoul (__const char *__restrict __nptr,       char **__restrict __endptr, int __base);
int find_reloads (int i, char *p)
{
  int c;
  while ((c = *p++))
    return strtoul (p - 1, &p, 10); 
  return 0;
}
