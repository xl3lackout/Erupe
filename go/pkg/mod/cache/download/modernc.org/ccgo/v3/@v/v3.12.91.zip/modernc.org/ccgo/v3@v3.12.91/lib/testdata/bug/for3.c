int main() {
	for (int i = 0, j = i; j < 5; j++) {}
	return 0;
}
