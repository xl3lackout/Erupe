typedef union
{
  char c;
  double f;
} Union;

typedef struct
{
  int Count;
  Union List[0];
} Struct3;

int main() {
}
