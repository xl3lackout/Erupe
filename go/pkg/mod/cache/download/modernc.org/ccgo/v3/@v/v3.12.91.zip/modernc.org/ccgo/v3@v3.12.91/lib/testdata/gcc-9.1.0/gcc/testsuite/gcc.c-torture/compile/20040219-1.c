double foo() { return __builtin_isgreater(0.,0.); }
